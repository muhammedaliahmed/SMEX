package com.example.smex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
